# Vroom — obtenir l'APK (sans rien installer sur PC)

1. Créez un compte gratuit sur github.com, puis un nouveau dépôt (privé si vous voulez).
2. Cliquez « Add file > Upload files » et déposez TOUT le contenu de ce dossier
   (y compris le dossier .github, www, package.json, capacitor.config.json).
3. Ouvrez l'onglet « Actions » : « Construire l'APK » démarre seul (5 à 10 min).
4. Une fois terminé, ouvrez l'exécution, section « Artifacts », téléchargez « Vroom-APK ».
5. Décompressez, copiez app-debug.apk sur votre téléphone, ouvrez-le et autorisez
   l'installation depuis cette source.

Alternative : Android Studio > « npm install », « npx cap add android », « npx cap open android ».
